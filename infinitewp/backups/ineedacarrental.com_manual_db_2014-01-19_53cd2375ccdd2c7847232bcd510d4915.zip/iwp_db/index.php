<?php
			global $old_url, $old_file_path;
			$old_url = 'http://ineedacarrental.com';
			$old_file_path = '/nfs/c01/h06/mnt/9842/domains/ineedacarrental.com/html/';
			